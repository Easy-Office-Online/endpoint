Most of OnedriveMapper's documentation and an FAQ can be found on my blog here: https://www.lieben.nu/liebensraum/onedrivemapper/
