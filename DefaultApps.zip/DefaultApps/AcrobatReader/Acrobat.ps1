﻿Import-Module $env:ProgramData\eoo\DefaultApps\PS-SFTA-master\sfta.ps1
Set-FTA Acrobat.Document.DC .pdf